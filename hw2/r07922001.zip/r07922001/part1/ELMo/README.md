# how to train my model
Go to the folder r07922001/part1/. Then, `python -m ELMo.train`.

# how to plot the figures in my report
put the log.csv in this folder and run `python plot.py`
make sure that you have visdom server and change the login config in plot.py
