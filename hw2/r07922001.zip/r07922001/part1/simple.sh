#! /bin/sh
python3.7 -m BCN.predict ./model/submission 6
