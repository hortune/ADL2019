# How to train
download stuff first `./download.sh`
then train `python -m BERT_large_casd.train`

