#! /bin/bash
python3.6 test.py -i $1  -o $2
